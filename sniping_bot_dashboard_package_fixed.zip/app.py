from flask import Flask, render_template, jsonify, request, session, redirect
import sqlite3
import pandas as pd

app = Flask(__name__)
app.secret_key = "your_secure_secret_key"

DB_FILE = "sniping_data.db"

def get_db_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def index():
    if not session.get("logged_in"):
        return redirect("/login")
    conn = get_db_connection()
    df = pd.read_sql_query("SELECT * FROM transactions", conn)
    conn.close()
    report = df.to_dict(orient="records")
    return render_template("dashboard_template.html", report=report)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        password = request.form.get("password")
        if password == "securepassword123":
            session["logged_in"] = True
            return redirect("/")
        else:
            return "Incorrect password", 403
    return render_template("login.html")

@app.route("/logout")
def logout():
    session["logged_in"] = False
    return redirect("/login")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
