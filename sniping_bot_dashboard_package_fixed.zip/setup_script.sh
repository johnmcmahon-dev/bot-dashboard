#!/bin/bash

# Automated Setup Script for Sniping Bot Dashboard (Docker-Compatible)

set -e  # Stop on error

echo "🚀 Starting Setup..."

# Update system packages
echo "🔄 Updating packages..."
apt update && apt upgrade -y

# Install necessary dependencies
echo "📦 Installing dependencies..."
apt install -y python3 python3-venv python3-pip nginx sqlite3 libsqlite3-dev

# Set up project directory
echo "📁 Setting up project directory..."
PROJECT_DIR="/app"
rm -rf $PROJECT_DIR
mkdir -p $PROJECT_DIR
cd /app

# Set up Python Virtual Environment
echo "🐍 Setting up Python Virtual Environment..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip

# Ensure sqlite3 is not listed in requirements.txt
sed -i '/sqlite3/d' requirements.txt

# Install required Python packages
echo "📦 Installing Python dependencies..."
pip install -r requirements.txt

# Complete
echo "✅ Setup complete!"
echo "📊 Your dashboard is now accessible at: http://localhost"
