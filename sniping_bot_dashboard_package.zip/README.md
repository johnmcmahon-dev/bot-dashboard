# Sniping Bot Dashboard

## Installation & Deployment

### 1. Local Deployment
1. Install Python 3.8+
2. Run:
   ```sh
   pip install -r requirements.txt
   python app.py
   ```
3. Open [http://127.0.0.1:5000](http://127.0.0.1:5000)

### 2. Docker Deployment (Recommended)
1. Install Docker & Docker Compose
2. Run:
   ```sh
   docker-compose up -d
   ```
3. Open [http://127.0.0.1:5000](http://127.0.0.1:5000)

## Login Credentials
- **Username:** Admin (not required)
- **Password:** `securepassword123` (Change this in `app.py`)
