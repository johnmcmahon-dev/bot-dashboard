#!/bin/bash

# Automated Setup Script for Sniping Bot Dashboard (Docker-Compatible)

set -e  # Stop on error

echo "🚀 Starting Setup..."

# Update system packages
echo "🔄 Updating packages..."
apt update && apt upgrade -y

# Install necessary dependencies
echo "📦 Installing dependencies..."
apt install -y python3 python3-venv python3-pip nginx sqlite3 libsqlite3-dev

# Set up project directory
echo "📁 Setting up project directory..."
PROJECT_DIR="/app"
rm -rf $PROJECT_DIR
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

# Download the latest Sniping Bot Dashboard Package
echo "⬇️ Downloading package..."
wget -O dashboard.zip "https://github.com/johnmcmahon-dev/bot-dashboard/raw/main/sniping_bot_dashboard_package.zip"
unzip dashboard.zip -d /app
cd /app

# Set up Python Virtual Environment
echo "🐍 Setting up Python Virtual Environment..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip

# Ensure sqlite3 is not listed in requirements.txt
sed -i '/sqlite3/d' requirements.txt

# Install required Python packages
echo "📦 Installing Python dependencies..."
pip install -r requirements.txt

# Start the application with Gunicorn
echo "🚀 Starting Flask App with Gunicorn..."
gunicorn -w 4 -b 0.0.0.0:5000 app:app &

# Set up Nginx Reverse Proxy
echo "🌐 Configuring Nginx..."
tee /etc/nginx/sites-available/sniping_dashboard <<EOF
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

ln -s /etc/nginx/sites-available/sniping_dashboard /etc/nginx/sites-enabled/
service nginx start

# Complete
echo "✅ Setup complete!"
echo "📊 Your dashboard is now accessible at: http://localhost"

tail -f /dev/null  # Keep container running
